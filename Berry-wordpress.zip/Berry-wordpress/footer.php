    <footer class="site-footer">
        <div class="container">
            Made with
            <span class="cute">♥</span>
            <span class="sep"></span>
            just a
            <a href="https://fatesinger.com" target="_blank">bigfa</a>
            theme.
        </div>
    </footer>
</div>
<?php wp_footer();?>
</body>
</html>
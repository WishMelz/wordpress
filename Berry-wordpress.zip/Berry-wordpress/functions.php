<?php
define('BERRY_VERSION', '1.0.5');
define('BERRY_DEBUG', false);

require('inc/setup.php');
require('inc/static.php');
require('inc/base.php');